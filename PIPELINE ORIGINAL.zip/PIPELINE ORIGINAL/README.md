# NCC Pipeline - Modular Version

Pipeline đã được tách thành các sections độc lập để dễ bảo trì và phát triển.

## 📁 Cấu trúc Files

### **Core Files (Cần thiết):**
- **`run_pipeline.py`** - Main runner để chạy pipeline
- **`final_unified_pipeline.py`** - Pipeline chính kết nối tất cả sections
- **`standalone_config.py`** - Config class độc lập
- **`NCC_PIPELINE_NEW.py`** - File gốc (backup)

### **Utility Files (Tools):**
- **`split_pipeline.py`** - Tool tách file gốc thành sections
- **`rename_sections.py`** - Tool đổi tên sections

### **Sections Directory:**
- **`sections/`** - Thư mục chứa 10 sections A-J
  - `SECTION_A_CONFIG_UTILS.py` - Config & Utils
  - `SECTION_B_GROUNDING_DINO_WRAPPER.py` - GroundingDINO
  - `SECTION_C_BACKGROUND_REMOVAL_WRAPPER.py` - Background Removal
  - `SECTION_D_U2NET_ARCHITECTURE.py` - U²-Net Architecture
  - `SECTION_E_QR_HELPERS.py` - QR Helpers
  - `SECTION_F_DATASET_WRITER.py` - Dataset Writer
  - `SECTION_G_SDY_PIPELINE.py` - SDY Pipeline
  - `SECTION_H_WAREHOUSE_CHECKER.py` - Warehouse Checker
  - `SECTION_I_UI_HANDLERS.py` - UI Handlers
  - `SECTION_J_UI_BUILD_LAUNCH.py` - UI Build & Launch

## 🚀 Cách sử dụng

### **Chạy Pipeline:**
```bash
# Chạy UI (Gradio Interface)
python run_pipeline.py --ui

# Chạy pipeline thông thường
python run_pipeline.py

# Test pipeline
python run_pipeline.py --test

# Xem help
python run_pipeline.py --show-help
```

### **Tái tạo Sections (nếu cần):**
```bash
# Tách file gốc thành sections
python split_pipeline.py

# Đổi tên sections
python rename_sections.py
```

## ✨ Tính năng

- **✅ Hoàn toàn độc lập**: Không phụ thuộc file gốc
- **✅ Modular**: Từng section có thể sửa riêng
- **✅ Tương đương file gốc**: Tất cả chức năng đều có
- **✅ Dễ bảo trì**: Cấu trúc rõ ràng, dễ debug
- **✅ Tự động hóa**: Có tools để tái tạo sections

## 🔧 Development

### **Sửa một section:**
1. Sửa file trong `sections/`
2. Chạy `python run_pipeline.py --test` để test
3. Chạy `python run_pipeline.py --ui` để test UI

### **Thêm section mới:**
1. Tạo file mới trong `sections/`
2. Cập nhật `final_unified_pipeline.py`
3. Test và deploy

## 📊 Status

- **Pipeline**: ✅ Hoạt động 100% (10/10 sections)
- **UI**: ✅ Gradio interface hoạt động
- **Config**: ✅ Standalone config
- **Dependencies**: ✅ Tất cả resolved
